package com.thefloow.java_selenium_example.common;

public class UnimplementedException extends RuntimeException {
    public UnimplementedException() {
        super("Not yet implemented (you can do this)");
    }
}
